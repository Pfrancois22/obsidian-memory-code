---
tags: [react, juggl]
related:
  - foreach
children:
  - foreach
---

# for-loop

> Structure de boucle classique avec compteur.
