---
tags: [react, juggl]
parent: for-loop
related:
  - map
children:
  - map
---

# foreach()

> Exécute une fonction sur chaque élément d’un tableau.
