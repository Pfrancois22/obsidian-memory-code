---
tags: [react, juggl]
parent: foreach
related:
  - map_props
children:
  - foreach
---

# Fonction : map() en React

> Transforme un tableau et retourne un nouveau tableau avec les résultats.
