---
tags: [react, juggl]
parent: map
related:
  - map
children: []
---

# map avec props

> Utilisation de map() dans un composant React avec props.
